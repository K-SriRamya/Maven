package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entity.Country;
import com.cg.spring.staticdb.CountryDb;

public class CountryDaoImpl implements ICountryDao {

	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return CountryDb.getCountryList();
	}
	

}
