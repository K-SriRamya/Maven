package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entity.Country;

public interface ICountryDao {
	public List<Country> getAllCountries();

}
