package com.cg.spring.service;

import java.util.List;

import com.cg.spring.entity.Country;

public interface ICountryService {
	
	public List<Country> getAllCountries();

}
