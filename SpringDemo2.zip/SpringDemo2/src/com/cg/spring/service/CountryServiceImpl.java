package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.ICountryDao;
import com.cg.spring.entity.Country;

@Service
public class CountryServiceImpl implements ICountryService {

	@Autowired
	ICountryDao countryDao;

	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return countryDao.getAllCountries();
	}
	
}
