package com.cg.spring.staticdb;

import java.util.ArrayList;

import com.cg.spring.entity.Country;

public class CountryDb {
	private static ArrayList<Country> countryList=new ArrayList<Country>();
	
	static {
		countryList.add(new Country("1001","India","123456"));
		countryList.add(new Country("1002","USA","642836"));
		countryList.add(new Country("1003","China","357903"));
		countryList.add(new Country("1004","UK","642168"));
		countryList.add(new Country("1005","SriLanka","236905"));

	}

	public static ArrayList<Country> getCountryList() {
		return countryList;
	}

	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = countryList;
	}
	


}